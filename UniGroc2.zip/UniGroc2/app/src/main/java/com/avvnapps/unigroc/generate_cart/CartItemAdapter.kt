package com.avvnapps.unigroc.generate_cart

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.avvnapps.unigroc.R
import com.avvnapps.unigroc.database.cart.CartEntity
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.item_cart.view.*

class CartItemAdapter(var context: Context, val cartList: List<CartEntity>): RecyclerView.Adapter<CartItemAdapter.ViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val itemView = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_cart, parent, false)

        return ViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return cartList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val cartItem = cartList.get(position)
        holder.bindItems(context,cartItem)
    }


    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bindItems(context: Context,cartItem: CartEntity){
            itemView.item_cart_name_tv.text = cartItem.name
            itemView.item_cart_price_tv.text = cartItem.price.toString()
            itemView.item_cart_metric_weight_tv.text = cartItem.metricWeight
            itemView.item_cart_quantity_tv.text = cartItem.quantity.toString()

            if(cartItem.quantity == 0){
                itemView.item_cart_add_large_btn.visibility = View.VISIBLE
                itemView.item_cart_subtract_btn.visibility = View.INVISIBLE
            }
            else{
                itemView.item_cart_add_large_btn.visibility = View.GONE
                itemView.item_cart_subtract_btn.visibility = View.VISIBLE
            }


            if(cartItem.photoUrl != null){
                Glide.with(context).load(cartItem.photoUrl).into(itemView.item_cart_iv)
            }


            itemView.item_cart_add_btn.setOnClickListener {
                cartItem.incrementQuantity()
                updateViews(cartItem)

            }
            itemView.item_cart_add_large_btn.setOnClickListener {
                cartItem.incrementQuantity()
                updateViews(cartItem)
            }
            itemView.item_cart_subtract_btn.setOnClickListener {
                cartItem.decrementQuantity()
                updateViews(cartItem)
            }

        }
        fun updateViews(cartItem: CartEntity){
            itemView.item_cart_quantity_tv.text = cartItem.quantity.toString()
            if(cartItem.quantity == 0){
                itemView.item_cart_add_large_btn.visibility = View.VISIBLE
                itemView.item_cart_subtract_btn.visibility = View.INVISIBLE
            }
            else{
                itemView.item_cart_add_large_btn.visibility = View.GONE
                itemView.item_cart_subtract_btn.visibility = View.VISIBLE
            }
        }

    }
}