package com.avvnapps.unigroc.generate_cart

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import com.arlib.floatingsearchview.FloatingSearchView
import com.arlib.floatingsearchview.suggestions.model.SearchSuggestion
import com.avvnapps.unigroc.database.cart.CartEntity
import com.avvnapps.unigroc.viewmodel.FirestoreViewModel
import kotlinx.android.synthetic.main.activity_search_item.*
import android.support.v7.widget.DividerItemDecoration
import android.view.View
import android.widget.ImageView
import com.bumptech.glide.Glide


class SearchItemActivity : AppCompatActivity() {

    val TAG = "SEARCH_ITEM_ACTIVITY"
    lateinit var firestoreViewModel: FirestoreViewModel
    lateinit var availableCartItems : List<CartEntity>
    lateinit var filteredCartItems : List<CartEntity>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.avvnapps.unigroc.R.layout.activity_search_item)

        activity_search_progress_bar.visibility = View.VISIBLE
        firestoreViewModel = ViewModelProviders.of(this).get(FirestoreViewModel::class.java)
        firestoreViewModel.getAvailableCartItems().observe(this,Observer{
            availableCartItems = it!!
            setSearchBar()
            activity_search_progress_bar.visibility = View.GONE

        })

        activity_search_item_rv.layoutManager = LinearLayoutManager(this)
        activity_search_item_rv.addItemDecoration(DividerItemDecoration(
            activity_search_item_rv.context, DividerItemDecoration.VERTICAL))
    }


    fun  setSearchBar(){
        activity_search_floating_search_view.setOnQueryChangeListener{oldQuery, newQuery ->

            if(oldQuery!="" && newQuery == "")
                activity_search_floating_search_view.clearSuggestions()
            else{
                activity_search_floating_search_view.showProgress()
                // search action
                filteredCartItems = filterCartItems(availableCartItems,newQuery)
                activity_search_floating_search_view.swapSuggestions(filteredCartItems)
                activity_search_floating_search_view.hideProgress()
                updateRecylerView(filteredCartItems)

            }
        }

       activity_search_floating_search_view.setOnSearchListener(object : FloatingSearchView.OnSearchListener{
           override fun onSuggestionClicked(searchSuggestion: SearchSuggestion?) {

               val cartItem = searchSuggestion as CartEntity
                Log.i(TAG,"Item Clicked: ${cartItem.body}")
               filteredCartItems = filterCartItems(availableCartItems,cartItem.name)
               updateRecylerView(filteredCartItems)
               activity_search_floating_search_view.clearSearchFocus()
           }

           override fun onSearchAction(currentQuery: String?) {
               activity_search_floating_search_view.showProgress()
               // search action
               filteredCartItems = filterCartItems(availableCartItems,currentQuery!!)
               activity_search_floating_search_view.swapSuggestions(filteredCartItems)
               activity_search_floating_search_view.hideProgress()
               updateRecylerView(filteredCartItems)
           }
       })


        activity_search_floating_search_view.setOnBindSuggestionCallback {
                suggestionView, leftIcon, textView, item, itemPosition ->
            val cartItem = item as CartEntity
            textView!!.text = cartItem.body
            leftIcon.scaleType = ImageView.ScaleType.CENTER_CROP
            if(cartItem.photoUrl != null)
                Glide.with(this@SearchItemActivity).load(cartItem.photoUrl).into(leftIcon!!)

        }
    }

    fun filterCartItems(cartList : List<CartEntity>, searchQuery:String): List<CartEntity> {


        val filteredValues = ArrayList<CartEntity>(cartList)
        for (cartItem in cartList) {
            val searchText = "${cartItem.name}  ${cartItem.category}  ${cartItem.clubbedCategory}"
            if (!(searchText.toLowerCase()).contains(searchQuery.toLowerCase()))
                filteredValues.remove(cartItem)

        }

        return filteredValues

    }

    fun updateRecylerView(cartList: List<CartEntity>){
        activity_search_item_rv.adapter = CartItemAdapter(this,cartList)
    }
}
